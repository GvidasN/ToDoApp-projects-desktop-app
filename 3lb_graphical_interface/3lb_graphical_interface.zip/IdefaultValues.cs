﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3lb_graphical_interface
{
    interface IdefaultValues
    {
        void firstValues(string value);
    }
}
