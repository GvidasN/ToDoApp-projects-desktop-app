﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3lb_graphical_interface
{
    class Project
    {
        private int id;
        private static int idAdder = 1;
        private String title;

        public Project(String title, string creator)
        {
            this.title = title;
            id = idAdder;
            idAdder++;
        }
   
        public override String ToString()
        {
            return title;
        }
    }
}
